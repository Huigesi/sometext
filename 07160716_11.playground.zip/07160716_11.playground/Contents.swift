//: Playground - noun: a place where people can play

import UIKit


func count() -> Int{
    var a:Int=0
    var lastday:Int=1
    for _ in 1...9 {
        a=(lastday+1)*2//前一天剩多少
        lastday=a
    }
    return a
}

count()

func count1(x:Int,y:Int,z:Int)->Int{
    return x*3+y*2+z*1
}
for m in 1...20{
    for f in 1...25{
        if(count1(x:m,y:f,z:30-m-f)==50){
            print("男人:\(m) 女人:\(f) 孩子:\(30-m-f)")
            break
        }
    }
}