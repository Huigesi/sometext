//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var array=[1,2,3]

func count(n:Int)->Int{
    let a=array[0];
    let b=array[1];
    let c=array[2];
    let e:Double = pow(Double(a), Double(n));
    let f:Double = pow(Double(b), Double(n));
    let g:Double = pow(Double(c), Double(n));
    
    
    let d:Double=e+f+g;
    
    return Int(d)
    
}
count(n: 5);
func count2(a:Int,b:Int,c:Int)->Int{
    var d:Int=0;
    if(a>b&&a>c){
        d=a;
    }else if(b>a&&b>c){
        d=b;
    }else if(c>a&&c>b){
        d=c;
    }
    return d
}
count2(a: 1, b: 30, c:4)

func count3(a: Double, b: Double, c: Double)->(v:Double,n:Double){
    let d:Double=(a+b+c)/3;
    let f:Double=a*a+b*b+c*c;
    return (f,d)
}
count3(a: 250, b: 240, c: 260)
func swap( a:inout Int, b:inout Int)
{
    let temp=a
    a=b
    b=temp
}
var a=1
var b=2
swap(&a,&b)

